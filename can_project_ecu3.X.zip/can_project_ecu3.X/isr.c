#include <xc.h>
#include "isr.h"

//extern volatile unsigned char blink_flag;

/*void __interrupt() isr(void)
{
    static unsigned char count = 0;

    if (TMR0IF)
    {
        TMR0IF = 0;
        TMR0 = 6;

        if (++count >= 25)   // adjust based on real tick (~200ms?500ms)
        {
            count = 0;
            blink_flag = !blink_flag;
        }
    }
}
 * */
