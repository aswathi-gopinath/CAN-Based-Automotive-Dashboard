#include <xc.h>
#include <stdint.h>
#include <string.h>

#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include "message_handler.h"
#include "isr.h"
#include "timer0.h"

volatile uint8_t ind = 0;
volatile uint16_t delay = 0;

static void init_config(void)
{
    init_clcd();
    init_can();

    TRISB = 0x08;   // RB3 input, others output
    PORTB = 0x00;

    PEIE = 1;
    GIE = 1;

    init_timer0();
}

void main(void)
{
    init_config();

    while(1)
    {
        process_canbus_data();

        // ? ONLY delay system (software counter)
        delay++;

        if(delay >= 1000)
            delay = 0;
    }
}