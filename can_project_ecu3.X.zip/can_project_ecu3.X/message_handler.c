#include <xc.h>
#include <string.h>
#include "message_handler.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"

void handle_speed_data(uint8_t *data, uint8_t len)
{
    char buff[9];

    if(len > 8)
        len = 8;

    memcpy(buff, data, len);
    buff[len] = '\0';

    clcd_print("SPD ", LINE1(0));
    clcd_print(buff, LINE2(0));
}

void handle_gear_data(uint8_t *data, uint8_t len) 
{
    char buff[9];

    if(len > 8)
        len = 8;

    memcpy(buff, data, len);
    buff[len] = '\0';

    clcd_print("GR", LINE1(13));

    if(strcmp(buff, "GC") == 0)
    {
        clcd_print("ACC", LINE2(13));
    }
    else
    {
        clcd_print("   ", LINE2(13));
        clcd_print(buff, LINE2(13));
    }
}

void handle_rpm_data(uint8_t *data, uint8_t len) 
{
    char buff[9];

    if(len > 8)
        len = 8;

    memcpy(buff, data, len);
    buff[len] = '\0';

    clcd_print("RPM", LINE1(9));
    clcd_print(buff, LINE2(9));
}

void handle_indicator_data(uint8_t *data, uint8_t len)
{
    char msg[9];
    static unsigned int delay = 0;   // ? ONLY delay used internally

    if(len == 0)
        return;

    if(len > 8)
        len = 8;

    memcpy(msg, data, len);
    msg[len] = '\0';

    clcd_print("IND", LINE1(4));

    /* ---------------- LEFT ---------------- */
    if(strcmp(msg, IND_LEFT) == 0)
    {
        RB7 = 0;

        if(delay < 500)
            RB0 = 1;
        else if(delay < 1000)
            RB0 = 0;
        else
            delay = 0;

        clcd_putch('<', LINE2(4));
        clcd_putch('-', LINE2(5));
    }

    /* ---------------- RIGHT ---------------- */
    else if(strcmp(msg, IND_RIGHT) == 0)
    {
        RB0 = 0;

        if(delay < 500)
            RB7 = 1;
        else if(delay < 1000)
            RB7 = 0;
        else
            delay = 0;

        clcd_putch('-', LINE2(4));
        clcd_putch('>', LINE2(5));
    }

    /* ---------------- HAZARD ---------------- */
    else if(strcmp(msg, IND_HAZARD) == 0)
    {
        if(delay < 500)
        {
            RB0 = 1;
            RB7 = 1;
        }
        else if(delay < 1000)
        {
            RB0 = 0;
            RB7 = 0;
        }
        else
        {
            delay = 0;
        }

        clcd_putch('<', LINE2(4));
        clcd_putch('-', LINE2(5));
        clcd_putch('-', LINE2(6));
        clcd_putch('>', LINE2(7));
    }

    /* ---------------- OFF ---------------- */
    else if(strcmp(msg, IND_OFF) == 0)
    {
        RB0 = 0;
        RB7 = 0;
        delay = 0;

        clcd_putch('O', LINE2(4));
        clcd_putch('F', LINE2(5));
        clcd_putch('F', LINE2(6));
        clcd_putch(' ', LINE2(7));
    }

    delay++;
}

void process_canbus_data() 
{   
    uint16_t msg_id;
    uint8_t data[8];
    uint8_t len;

    can_receive(&msg_id, data, &len);

    if(len == 0)
        return;

    switch(msg_id)
    {
        case SPEED_MSG_ID:
            handle_speed_data(data, len);
            break;

        case INDICATOR_MSG_ID:
            handle_indicator_data(data, len); 
            break;

        case RPM_MSG_ID:
            handle_rpm_data(data, len);
            break;

        case GEAR_MSG_ID:
            handle_gear_data(data, len);
            break;
    }
}