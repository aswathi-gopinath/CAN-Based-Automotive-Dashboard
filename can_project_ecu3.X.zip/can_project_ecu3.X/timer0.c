#include <xc.h>
#include "timer0.h"

void init_timer0(void)
{
    T08BIT = 1;     // 8-bit
    T0CS = 0;       // internal clock
    PSA = 1;        // no prescaler

    TMR0 = 6;       // preload

    TMR0IF = 0;
    TMR0IE = 1;
    TMR0ON = 1;
}
