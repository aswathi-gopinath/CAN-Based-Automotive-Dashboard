/* 
 * File:   ecu1_sensor.h
 * Author: Emertxe
 *
 * Created on March 20, 2025, 6:14 PM
 */
#ifndef ECU1_SENSOR_H
#define	ECU1_SENSOR_H

#include <stdint.h>
#include "matrix_keypad.h"
#include <xc.h>

#define SPEED_ADC_CHANNEL 0x04

#define IND_LEFT  "LEFT"
#define IND_RIGHT "RIGHT"
#define IND_HAZARD "HAZARD"
#define IND_OFF   "OFF"

void get_speed();
void process_indicator();

#endif	/* ECU1_SENSOR_H */

