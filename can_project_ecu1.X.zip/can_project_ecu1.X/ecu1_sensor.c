#include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include"string.h"
#include <stdio.h>

void get_speed(void)
{
    unsigned short adc_value;
    static int prev_speed = -1;   
    int speed;
    int len;
    char buffer[6];

    adc_value = read_adc(CHANNEL4);

    speed = (adc_value * 100)/ 1023;

    /* Transmit only if speed changed */
    if(speed != prev_speed)
    {
        sprintf(buffer, "%d", speed);  
        len = strlen(buffer);

        can_transmit(SPEED_MSG_ID, (uint8_t*)buffer, len);

        prev_speed = speed;   // update current speed
    }
}

void process_indicator()
{
    uint8_t key;
    key = read_switches(STATE_CHANGE);
    switch(key)
    {
        case MK_SW1:
            can_transmit(INDICATOR_MSG_ID , IND_LEFT, sizeof(IND_LEFT) - 1);
            break;
        case MK_SW2 :
            can_transmit(INDICATOR_MSG_ID , IND_RIGHT,  sizeof(IND_RIGHT) - 1);
            break;
        case MK_SW3 :
            can_transmit(INDICATOR_MSG_ID , IND_HAZARD,  sizeof(IND_HAZARD) - 1);
            break;
        case MK_SW4 :
            can_transmit(INDICATOR_MSG_ID , IND_OFF,  sizeof(IND_OFF) - 1);
            break;
    }
}