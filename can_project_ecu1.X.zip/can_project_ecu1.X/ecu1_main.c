#include <xc.h>
#include "adc.h"
#include "can.h"
#include "matrix_keypad.h"
#include "ecu1_sensor.h"

#define _XTAL_FREQ 20000000

/* System Initialization */
void init_config(void)
{
    init_can();
    init_adc();
    init_matrix_keypad();
}

/* Main Application */
void main(void)
{
    init_config();

    while(1)
    {
        get_speed();          
       // __delay_ms(50);
        process_indicator();  
        __delay_ms(50);
    }
}
