/* 
 * File:   ecu1_sensor.h
 * Author: Emertxe
 *
 * Created on March 20, 2025, 6:14 PM
 */
#ifndef ECU2_SENSOR_H
#define	ECU2_SENSOR_H

#include <stdint.h>
#include "matrix_keypad.h"
#include <xc.h>

#define RPM_ADC_CHANNEL 0x04
#define MAX_GEAR 6
#define GEAR_UP             MK_SW1
#define GEAR_DOWN           MK_SW2
#define COLLISION           MK_SW3

void  get_rpm();
void get_gear_pos();

#endif	/* ECU2_SENSOR_H */

