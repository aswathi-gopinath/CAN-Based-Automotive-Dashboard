#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"

#define _XTAL_FREQ 20000000

 void init_config(void)
{
    init_can();
    init_adc();
    init_matrix_keypad();
}

void main()
{
    init_config();
    while(1)
    {
        get_rpm();
        get_gear_pos();
        __delay_ms(50);
    }
}
