#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "matrix_keypad.h"
#include <string.h>
#include <stdio.h>

/* ================= RPM FUNCTION ================= */

void get_rpm(void)
{
    unsigned short adc_value;
    static unsigned int prev_adc = 0;
    static int prev_rpm = -1;

    int rpm;
    char buffer[6];

    adc_value = read_adc(CHANNEL4);

    /* simple smoothing filter */
    adc_value = (adc_value + prev_adc) / 2;
    prev_adc = adc_value;

    rpm = (adc_value * 6000) / 1023;

    if(rpm != prev_rpm)
    {
        sprintf(buffer, "%d", rpm);

        can_transmit(RPM_MSG_ID,
                     (uint8_t *)buffer,
                     strlen(buffer));

        prev_rpm = rpm;
    }
}



/* ================= GEAR FUNCTION ================= */

void get_gear_pos(void)
{
    const char gear[8][3] = {"GN","G1","G2","G3","G4","G5","GR","GC"};

    static int gear_index = 0;
    static int prev_index = -1;

    uint8_t key = read_switches(STATE_CHANGE);

    switch(key)
    {
        case GEAR_UP:
            if(gear_index == 7)        // if collision state
            {
                gear_index = 0;        // go to neutral
            }
            else if(gear_index < 6)
            {
                gear_index++;
            }
            break;

        case GEAR_DOWN:
            if(gear_index == 7)        // if collision state
            {
                gear_index = 0;        // go to neutral
            }
            else if(gear_index > 0)
            {
                gear_index--;
            }
            break;

        case COLLISION:
            gear_index = 7;            // collision
            break;

        default:
            break;
    }

    /* transmit only if changed */
    if(gear_index != prev_index)
    {
        can_transmit(GEAR_MSG_ID,
                     (uint8_t*)gear[gear_index],
                     strlen(gear[gear_index]));

        prev_index = gear_index;
    }
}
